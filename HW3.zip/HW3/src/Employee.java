/**
 * @author Casey Sweet 
 * Tucker
 * CS-372-Java
 * 1/8/2019
 */

 /** 
  * Interface to help see which people are employed and be able to give them pay
  */
public interface Employee{

    int PayDay();

    int getID();
}